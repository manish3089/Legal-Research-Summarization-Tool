---
configs:
- config_name: zero_billsum
  data_files:
  - split: train
    path: "zero_billsum/train.jsonl"
- config_name: zero_eurlexsum
  data_files:
  - split: train
    path: "zero_eurlexsum/train.jsonl"
- config_name: zero_govreport
  data_files:
  - split: train
    path: "zero_govreport/train.jsonl"
- config_name: zero_multilong
  data_files:
  - split: train
    path: "zero_multilong/train.jsonl"
- config_name: zero_multishort
  data_files:
  - split: train
    path: "zero_multishort/train.jsonl"
- config_name: zero_multitiny
  data_files:
  - split: train
    path: "zero_multitiny/train.jsonl"
- config_name: zero_inabs
  data_files:
  - split: train
    path: "zero_inabs/train.jsonl"
- config_name: zero_ukabs
  data_files:
  - split: train
    path: "zero_ukabs/train.jsonl"
---

# ZeroLexSumm Benchmark

The ZeroLexSumm Benchmark contains 8 datasets from various juresdictions such as the US, UK, EU, and India. The datasets are curated out of the LexSum datasets, each conatining 50 samples. All datasets adheres to the same format with columns: `input`, `output`, `id`, `cluster`, `old_id` and `length`. 

- `cluster`: which inout bracket 0-8k, 8k-16k, 16k+ and longest
- `old_id`: ID in the LexSumm dataset
- `length`: length of the input

Below you can find the links to the seperate datasets from ZeroLexSum.

- **[BillSum](https://huggingface.co/datasets/CJWeiss/LGZ_billsum)**: US Congressional bills with summaries by the Congressional Research Service.
- **[InAbs](https://huggingface.co/datasets/CJWeiss/LGZ_inabs)**: Indian Supreme Court cases with headnotes as summaries.
- **[UKAbs](https://huggingface.co/datasets/CJWeiss/LGZ_ukabs)**: UK Supreme Court judgments with official press summaries.
- **[EurLexSum](https://huggingface.co/datasets/CJWeiss/LGZ_eurlexsum)**: Summaries of enforced EU legislation from the EUR-Lex platform.
- **[GovReport](https://huggingface.co/datasets/CJWeiss/LGZ_govreport)**: U.S. Government Accountability Office reports with expert-written summaries.
- **[MultiLexSum-Long](https://huggingface.co/datasets/CJWeiss/LGZ_multilong)**: Multi-paragraph summaries of U.S. civil rights lawsuits.
- **[MultiLexSum-Short](https://huggingface.co/datasets/CJWeiss/LGZ_multishort)**: Single-paragraph summaries of civil rights lawsuits.
- **[MultiLexSum-Tiny](https://huggingface.co/datasets/CJWeiss/LGZ_multitiny)**: One-sentence summaries of civil rights lawsuits in Twitter-like format.